package com.example.codepathsummerinstructorsample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RoomTwoActivity extends AppCompatActivity {

    EditText edText;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_two);

        edText = findViewById(R.id.edText);
        button2 = findViewById(R.id.button2);

        // Take Info from edit text and send it to main activity
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String info = edText.getText().toString();
                Intent i = new Intent(getApplicationContext(), RoomOneActivity.class);
                i.putExtra("textInfo", info);
                startActivity(i);
                finish();


            }
        });





    }
}