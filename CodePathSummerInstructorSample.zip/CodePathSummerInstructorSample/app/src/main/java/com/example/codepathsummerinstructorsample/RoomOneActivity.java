package com.example.codepathsummerinstructorsample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class RoomOneActivity extends AppCompatActivity {

    TextView textFromSecondActivity;
    Button buttonMainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonMainActivity = findViewById(R.id.buttonMainActivity);
        textFromSecondActivity = findViewById(R.id.text3);




        // Go to second activity
        buttonMainActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RoomTwoActivity.class);
                startActivity(i);
            }
        });





        // get information from second activity
        String info = getIntent().getStringExtra("textInfo");
        textFromSecondActivity.setText(info);










    }
}